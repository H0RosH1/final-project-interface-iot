$('.brow1').width($('.trow1').width());
$('.brow2').width($('.trow2').width());
$('.brow3').width($('.trow3').width());
$('.brow4').width($('.trow4').width());
$('.brow5').width($('.trow5').width());
$('.brow6').width($('.trow6').width());
$('.brow7').width($('.trow7').width());
$(window).resize(function () {
    $('.brow1').width($('.trow1').width());
    $('.brow2').width($('.trow2').width());
    $('.brow3').width($('.trow3').width());
    $('.brow4').width($('.trow4').width());
    $('.brow5').width($('.trow5').width());
    $('.brow6').width($('.trow6').width());
    $('.brow7').width($('.trow7').width());
})
